<template>
   <div id="app">
    <router-view />
    </div>
</template>   

<script setup>
import { onMounted } from 'vue';
import { useAuthStore } from './stores/auth.store.js';

const authStore = useAuthStore();

onMounted(() => {
  authStore.initAuth();
});

</script>

<style>
#app {
  min-height: 100vh;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}


</style>