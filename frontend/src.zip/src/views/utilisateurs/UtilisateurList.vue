<template>
    <div class="page">
        <div class="page-header">
            <h1>Comptes utilisateurs</h1>
            <router-link to="/utilisateurs/nouveau" class="btn-primary">+ Nouvel agent</router-link>
        </div>
        <table>
            <thead>
                <tr><th>Nom</th><th>Email</th><th>Rôle</th><th>Statut</th><th></th></tr>
            </thead>
            <tbody>
                <tr v-for="u in users" :key="u.id">
                    <td>{{ u.nom }} {{ u.prenom }}</td>
                    <td>{{ u.email }}</td>
                    <td>{{ u.role }}</td>
                    <td>{{ u.actif ? "Actif" : "Désactivé" }}</td>
                    <td class="actions">
                        <router-link :to="`/utilisateurs/${u.id}/modifier`">Modifier</router-link>
                        <button @click="toggleActif(u)">{{ u.actif ? "Désactiver" : "Réactiver" }}</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import utilisateurService from "../../service/utilisateur.service.js";

const users = ref([]);

async function load() {
    const { data } = await utilisateurService.getAll();
    users.value = data.data ?? data;
}

async function toggleActif(u) {
    await utilisateurService.update(u.id, { actif: u.actif ? 0 : 1 });
    u.actif = u.actif ? 0 : 1;
}

onMounted(load);
</script>