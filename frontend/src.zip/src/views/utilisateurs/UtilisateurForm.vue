<template>
    <div class="page">
        <h1>Nouveau compte Agent FID</h1>
        <form @submit.prevent="onSubmit" class="form">
            <label>Nom <input v-model="form.nom" required /></label>
            <label>Prénom <input v-model="form.prenom" /></label>
            <label>Email <input v-model="form.email" type="email" required /></label>
            <label>Mot de passe initial <input v-model="form.mot_de_passe" type="password" required /></label>
            
            <p v-if="error" class="error">{{ error }}</p>
            <button type="submit" :disabled="saving">{{ saving ? "Création..." : "Créer le compte" }}</button>
        </form>
    </div>
</template>

<script setup>
import { reactive, ref } from "vue";
import { useRouter } from "vue-router";
import utilisateurService from "../../service/utilisateur.service.js";

const router = useRouter();
const form = reactive({ nom: "", prenom: "", email: "", mot_de_passe: "" });
const saving = ref(false);
const error = ref("");

async function onSubmit() {
    saving.value = true;
    error.value = "";
    try {
        await utilisateurService.create(form);
        router.push("/utilisateurs");
    } catch (e) {
        error.value = e.response?.data?.message || "Erreur lors de la création";
    } finally {
        saving.value = false;
    }
}
</script>