<template>
    <div class="page">
        <div class="page-header">
            <h1>Groupes VOAMAMI</h1>
            <router-link to="/voamami/nouveau" class="btn-primary">+ Nouveau groupe</router-link>
        </div>

        <p v-if="loading">Chargement...</p>
        <p v-else-if="error" class="error">{{ error }}</p>

        <table v-else>
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Nom</th>
                    <th>Fokontany</th>
                    <th>Commune</th>
                    <th>District</th>
                    <th>Région</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="v in voamami" :key="v.id">
                    <td>{{ v.code }}</td>
                    <td>{{ v.nom }}</td>
                    <td>{{ v.fokontany }}</td>
                    <td>{{ v.commune }}</td>
                    <td>{{ v.district }}</td>
                    <td>{{ v.region }}</td>
                    <td><span :class="['badge', v.statut.toLowerCase()]">{{ v.statut }}</span></td>
                    <td class="actions">
                        <router-link :to="`/voamami/${v.id}`">Voir</router-link>
                        <router-link :to="`/voamami/${v.id}/modifier`">Modifier</router-link>
                        <button @click="onDelete(v.id)">Supprimer</button>
                    </td>
                </tr>
                <tr v-if="voamami.length === 0">
                    <td colspan="7">Aucun groupe enregistré.</td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import voamamiService from "../../service/voamami.service";

const voamami = ref([]);
const loading = ref(true);
const error = ref("");

async function load() {
    loading.value = true;
    error.value = "";
    try {
        const { data } = await voamamiService.getAll();
        voamami.value = data.data;
    } catch (e) {
        error.value = e.response?.data?.message || "Erreur de chargement";
    } finally {
        loading.value = false;
    }
}

async function onDelete(id) {
    if (!confirm("Supprimer ce groupe VOAMAMI ?")) return;
    try {
        await voamamiService.remove(id);
        voamami.value = voamami.value.filter((v) => v.id !== id);
    } catch (e) {
        alert(e.response?.data?.message || "Suppression impossible");
    }
}

onMounted(load);
</script>

<style scoped>
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; }
table { width: 100%; border-collapse: collapse; }
th, td { text-align: left; padding: 0.6rem; border-bottom: 1px solid #e2e8f0; }
.actions { display: flex; gap: 0.75rem; }
.badge { padding: 0.15rem 0.5rem; border-radius: 4px; font-size: 0.8rem; }
.badge.actif { background: #dcfce7; color: #166534; }
.badge.inactif, .badge.cloture { background: #fee2e2; color: #991b1b; }
.btn-primary { background: #1e293b; color: #fff; padding: 0.5rem 1rem; border-radius: 6px; text-decoration: none; }
</style>