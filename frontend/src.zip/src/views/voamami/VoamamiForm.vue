<template>
    <div class="page">
        <h1>{{ isEdit ? "Modifier" : "Nouveau" }} groupe VOAMAMI</h1>
<pre>{{ authStore.user }}</pre>
        <form @submit.prevent="onSubmit" class="form">
            <label>Code
                <input v-model="form.code" required />
            </label>
            <label>Nom
                <input v-model="form.nom" required />
            </label>
             <label>Fokontany
                <input v-model="form.fokontany" />
            </label>
            <label>Commune
                <input v-model="form.commune" />
            </label>
            <label>District
                <input v-model="form.district" />
            </label>
            <label>Région
                <input v-model="form.region" />
            </label>
            <label>Date de création
                <input v-model="form.date_creation" type="date" required />
            </label>
            <label>Statut
                <select v-model="form.statut">
                    <option value="ACTIF">Actif</option>
                    <option value="INACTIF">Inactif</option>
                </select>
            </label>
            <label v-if="isEdit && isAdmin">
                Agent responsable
                <select v-model="form.agent_responsable_id">
                    <option :value="null">-- Aucun --</option>
                    <option v-for="a in agents" :key="a.id" :value="a.id">
                        {{ a.nom }} {{ a.prenom }}
                    </option>
                </select>
            </label>

            <p v-if="error" class="error">{{ error }}</p>

            <div class="form-actions">
                <button type="submit" :disabled="saving">{{ saving ? "Enregistrement..." : "Enregistrer" }}</button>
                <router-link to="/voamami">Annuler</router-link>
            </div>
        </form>
    </div>
</template>

<script setup>
import { ref, reactive, onMounted, computed } from "vue";
import { useRoute, useRouter } from "vue-router";
import { useAuthStore } from "../../stores/auth.store.js";
import voamamiService from "../../service/voamami.service.js";
import api from "../../service/api.js";

const route = useRoute();
const router = useRouter();
const isEdit = computed(() => !!route.params.id);
const authStore = useAuthStore();
const isAdmin = computed(() => authStore.user?.role === "ADMINISTRATEUR");

const form = reactive({
    code: "",
    nom: "",
    fokontany: "",
    commune: "",
    district: "",
    region: "",
    date_creation: "",
    statut: "ACTIF",
    agent_responsable_id: null,
});

const agents = ref([]);
const saving = ref(false);
const error = ref("");

onMounted(async () => {
    if (isEdit.value) {
        const { data } = await voamamiService.getById(route.params.id);
        Object.assign(form, data.data);
        if (form.date_creation) form.date_creation = form.date_creation.slice(0, 10);

        if (isAdmin.value) {
            const { data: agentsData } = await api.get("/utilisateurs?role=AGENT_FID");
            agents.value = agentsData.data ?? agentsData;
        }
    } else {
        form.agent_responsable_id = authStore.user?.id || null;
    }
});

async function onSubmit() {
    saving.value = true;
    error.value = "";
    try {
        if (isEdit.value) {
            await voamamiService.update(route.params.id, form);
        } else {
            await voamamiService.create(form);
        }
        router.push("/voamami");
    } catch (e) {
        error.value = e.response?.data?.message || "Erreur d'enregistrement";
    } finally {
        saving.value = false;
    }
}
</script>

<style scoped>
.form { display: flex; flex-direction: column; gap: 0.9rem; max-width: 480px; }
label { display: flex; flex-direction: column; gap: 0.3rem; font-size: 0.9rem; }
input, select { padding: 0.5rem; border: 1px solid #cbd5e1; border-radius: 6px; }
.form-actions { display: flex; gap: 1rem; align-items: center; margin-top: 0.5rem; }
</style>