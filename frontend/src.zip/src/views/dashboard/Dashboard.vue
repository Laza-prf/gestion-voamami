
<template>
    <h1>Admin Connecte</h1>
</template>