import { createRouter, createWebHistory } from "vue-router";
import { useAuthStore } from "../stores/auth.store.js";
import AppLayout from "../components/layouts/AppLayout.vue";

const routes = [
  { path: "/login", component: () => import("../views/auth/Login.vue") },
  {
    path: "/",
    component: AppLayout,
    meta: { requiresAuth: true },
    children: [
      { path: "", name: "dashboard", component: () => import("../views/dashboard/Dashboard.vue") },
      { path: "voamami", name: "voamami", component: () => import("../views/voamami/VoamamiList.vue") },
      { path: "voamami/nouveau", name: "voamami-create", component: () => import("../views/voamami/VoamamiForm.vue") },
      { path: "voamami/:id", name: "voamami-detail", component: () => import("../views/voamami/VoamamiDetail.vue") },
      { path: "voamami/:id/modifier", name: "voamami-edit", component: () => import("../views/voamami/VoamamiForm.vue") },
      { path: "utilisateurs", name: "utilisateurs", component: () => import("../views/utilisateurs/UtilisateurList.vue"), meta: { roles: ["ADMINISTRATEUR"] } },
      { path: "utilisateurs/nouveau", name: "utilisateurs-create", component: () => import("../views/utilisateurs/UtilisateurForm.vue"), meta: { roles: ["ADMINISTRATEUR"] } },
     // { path: "membres", name: "membres", component: () => import("../views/membres/MembreList.vue") },
     // { path: "cycles", name: "cycles", component: () => import("../views/cycles/CycleList.vue") },
     // { path: "seances", name: "seances", component: () => import("../views/seances/SeanceList.vue") },
     // { path: "epargnes", name: "epargnes", component: () => import("../views/epargnes/EpargneList.vue") },
     // { path: "credits", name: "credits", component: () => import("../views/credits/CreditList.vue") },
     // { path: "agr", name: "agr", component: () => import("@/views/agr/AgrListView.vue") },
    ],
  },
];

const router = createRouter({ history: createWebHistory(), routes });

router.beforeEach((to) => {
  const auth = useAuthStore();
  if (to.meta.requiresAuth && !auth.isAuthenticated) return "/login";
  if (to.meta.roles && !to.meta.roles.includes(auth.user?.role)) return "/"; // accès refusé
});

export default router;