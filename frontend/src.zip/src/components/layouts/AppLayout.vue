<template>
  <div class="layout">
    <Sidebar />
    <div class="main">
      <Navbar />
      <main class="content">
        <router-view />
      </main>
    </div>
  </div>
</template>

<script setup>
import Sidebar from "../layouts/Sidebar.vue";
import Navbar from "../layouts/Navbar.vue";
</script>

<style scoped>
.layout { display: flex; min-height: 100vh; }
.main { flex: 1; display: flex; flex-direction: column; }
.content { padding: 1.5rem; }
</style>