<template>
  <aside class="sidebar">
    <h2>VOAMAMI</h2>
    <nav>
      <router-link v-for="item in visibleItems" :key="item.to" :to="item.to">
        {{ item.label }}
      </router-link>
    </nav>
  </aside>
</template>

<script setup>
import { computed } from "vue";
import { useAuthStore } from "../../stores/auth.store.js";

const auth = useAuthStore();

console.log("auth.user =", auth.user);
console.log("auth.user.role =", auth.user?.role);

const menuItems = [
  { label: "Tableau de bord", to: "/" },
  { label: "VOAMAMI", to: "/voamami" },
  { label: "Membres", to: "/membres" },
  { label: "Cycles", to: "/cycles" },
  { label: "Séances", to: "/seances" },
  { label: "Épargnes", to: "/epargnes" },
  { label: "Crédits", to: "/credits" },
  { label: "AGR", to: "/agr", roles: ["ADMINISTRATEUR"] },
  { label: "Utilisateurs", to: "/utilisateurs", roles: ["ADMINISTRATEUR"] },

];

const visibleItems = computed(() => {
    const roleUtilisateur = auth.user?.role;

    return menuItems.filter((item) => {
        if (!item.roles) {
            return true;
        }

        return item.roles.includes(roleUtilisateur);
    });
});

</script>

<style scoped>
.sidebar {
  width: 220px;
  flex-shrink: 0;
  background: #1e293b;
  color: #fff;
  min-height: 100vh;
  padding: 1.5rem 1rem;
  box-sizing: border-box;
}
.sidebar h2 {
  margin: 0 0 1.5rem;
  font-size: 1.1rem;
}
.sidebar nav {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}
.sidebar nav a {
  color: #cbd5e1;
  text-decoration: none;
  padding: 0.6rem 0.75rem;
  border-radius: 6px;
}
.sidebar nav a:hover,
.sidebar nav a.router-link-active {
  background: #334155;
  color: #fff;
}
</style>