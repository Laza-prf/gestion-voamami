<!-- components/layout/Navbar.vue -->
<template>
  <header class="navbar">
    <div class="spacer" />
    <span>{{ auth.user?.nom }} ({{ auth.user?.role }})</span>
    <button @click="logout">Déconnexion</button>
  </header>
</template>

<script setup>
import { useAuthStore } from "../../stores/auth.store.js";
import { useRouter } from "vue-router";

const auth = useAuthStore();
const router = useRouter();

async function logout() {
  await auth.logout();
  router.push("/login");
}
</script>

<style scoped>
.navbar {
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 1.5rem;
  background: #fff;
  border-bottom: 1px solid #e2e8f0;
}
.logo { font-weight: 600; }
.user-zone {
  display: flex;
  align-items: center;
  gap: 1rem;
}
</style>