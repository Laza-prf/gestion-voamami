import api from "./api.js";

export default {
    getAll: (role) => api.get(`/users${role ? `?role=${role}` : ""}`),
    getById: (id) => api.get(`/users/${id}`),
    create: (data) => api.post("/users", data),
    update: (id, data) => api.put(`/users/${id}`, data),
    remove: (id) => api.delete(`/users/${id}`),
};